const chatForm = document.getElementById('chat-form');
const userInput = document.getElementById('user-input');
const chatWindow = document.getElementById('chat-window');

const OPENAI_API_KEY = "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";

chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const message = userInput.value.trim();

    if (!message) {
        return;
    }

    appendMessage('user', message);
    userInput.value = '';

    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${OPENAI_API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are a helpful assistant that diagnoses dog health symptoms." },
                    { role: "user", content: message }
                ]
            })
        });

        if (!response.ok) {
            appendMessage('bot', "Sorry, something went wrong with the API.");
            return;
        }

        const data = await response.json();

        if (data && data.choices && data.choices.length > 0) {
            const reply = data.choices[0].message?.content || "Sorry, no response from the model.";
            appendMessage('bot', reply);
        } else {
            appendMessage('bot', "Sorry, something went wrong with the response.");
        }

    } catch (error) {
        appendMessage('bot', "Sorry, something went wrong.");
    }
});

function appendMessage(sender, text) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);
    messageDiv.textContent = text;
    chatWindow.appendChild(messageDiv);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}

